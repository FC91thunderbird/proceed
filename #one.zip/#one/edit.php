<?php
$conn = mysqli_connect("localhost","root","","sample");

if (isset($_POST['AddNewRecord'])) {

	$firstname=$_POST['firstname'];
	$lastname=$_POST['lastname'];
	$address=$_POST['address'];

$procedure = "CREATE PROCEDURE insertUser(firstname varchar(20), lastname varchar(20), address varchar(50))  
                BEGIN  
                INSERT INTO user(firstname, lastname, address) VALUES (firstname, lastname, address);   
                END; ";  
           if(mysqli_query($conn, "DROP PROCEDURE IF EXISTS insertUser"))  
           {  
                if(mysqli_query($conn, $procedure))  
                {  
                     $query = "CALL insertUser('".$firstname."', '".$lastname."','".$address."')";  
                     mysqli_query($conn, $query);  
                     echo 'Data Inserted';  
                }  
           }  


	/*$firstname=$_POST['firstname'];
	$lastname=$_POST['lastname'];
	$address=$_POST['address'];
	
	mysqli_query($conn,"insert into user (firstname, lastname, address) values ('$firstname', '$lastname', '$address')");*/
	header('location:index.php');
}

if (isset($_POST['Edit1'])) {
	
	$id = $_POST['hidden_id'];
	$firstname=$_POST['firstname'];
	$lastname=$_POST['lastname'];
	$address=$_POST['address'];
	
	$procedure = "  
                CREATE PROCEDURE updateUser(IN userid int(11), firstname varchar(25), lastname varchar(25), address varchar(250))  
                BEGIN   
                UPDATE user SET firstname=firstname, lastname=lastname, address=address WHERE userid=userid;  
                END; ";    
           if(mysqli_query($conn, "DROP PROCEDURE IF EXISTS updateUser"))  
           {  
                if(mysqli_query($conn, $procedure))  
                {  
                     $query = "CALL updateUser('".$_POST['userid']."', '".$firstname."', '".$lastname."', , '".$address."') ";  
                     mysqli_query($conn, $query);  
                     echo 'Data Updated';  
                }  
           }  




/*	mysqli_query($conn,"update user set firstname='$firstname', lastname='$lastname', address='$address' where userid='$id'");*/
	header('location:index.php');
}
	
if (isset($_GET['del'])) {

	$procedure = "  
           CREATE PROCEDURE deleteUser(IN userid int(11))  
           BEGIN   
           DELETE FROM user WHERE userid = userid;  
           END;  
           ";  
           if(mysqli_query($conn, "DROP PROCEDURE IF EXISTS deleteUser"))  
           {  
                if(mysqli_query($conn, $procedure))  
                {  
                     $query = "CALL deleteUser('".$id."')";  
                     mysqli_query($conn, $query);  
                     echo 'Data Deleted';  
                }  
           }  



	
	/*$id=$_GET['del'];
	mysqli_query($conn,"delete from user where userid='$id'");*/
	header('location:index.php');
}
?>